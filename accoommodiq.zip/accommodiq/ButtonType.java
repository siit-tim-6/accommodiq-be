package example.pages.accommodiq;

public enum ButtonType {
    CANCEL,
    ACCEPT,
    DECLINE,
    DELETE,

}
