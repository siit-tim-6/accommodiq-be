package example.tests.accommodiq;

import example.pages.accommodiq.*;
import example.tests.TestBase;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static org.testng.Assert.*;

public class GuestReservationsTest extends TestBase {
    public static final int NUMBER_OF_NAVIGATION_BAR_TABS_GUEST = 6;
    public static final int NUMBER_OF_NAVIGATION_BAR_TABS_HOST = 8;
    public static final String GUEST_EMAIL = "guest.bj@example.com";
    public static final String GUEST_PASSWORD = "123";
    public static final String HOST_EMAIL = "john.doe@example.com";
    public static final String HOST_PASSWORD = "123";


    ArrayList<ReservationSummary> ss = new ArrayList<>();
    ArrayList<ReservationSummary> ss2 = new ArrayList<>();



    @BeforeClass
    public void setUp() {
        ss.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2023, 1, 1));
                    add(getDate(2023, 1, 2));
                }},
                ReservationStatus.DECLINED,
                2,
                new ArrayList<>() {
                }
        ));
        ss.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2023, 1, 2));
                    add(getDate(2023, 1, 3));
                }},
                ReservationStatus.ACCEPTED,
                4,
                new ArrayList<>() {
                }
        ));
        ss.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2023, 1, 3));
                    add(getDate(2023, 1, 4));
                }},
                ReservationStatus.CANCELLED,
                1,
                new ArrayList<>() {
                }
        ));
        ss.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2024, 3, 1));
                    add(getDate(2024, 3, 3));
                }},
                ReservationStatus.ACCEPTED,
                2,
                new ArrayList<>() {{
                    add(ButtonType.CANCEL);
                }}
        ));
        ss.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2024, 3, 5));
                    add(getDate(2024, 3, 6));
                }},
                ReservationStatus.PENDING,
                2,
                new ArrayList<>() {{
                    add(ButtonType.DELETE);
                }}
        ));
        //
        ss2.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2023, 1, 1));
                    add(getDate(2023, 1, 2));
                }},
                ReservationStatus.DECLINED,
                2,
                new ArrayList<>() {
                }
        ));
        ss2.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2023, 1, 3));
                    add(getDate(2023, 1, 4));
                }},
                ReservationStatus.CANCELLED,
                1,
                new ArrayList<>() {
                }
        ));
        ss2.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2024, 3, 1));
                    add(getDate(2024, 3, 3));
                }},
                ReservationStatus.ACCEPTED,
                2,
                new ArrayList<>()
        ));
        ss2.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2024, 3, 5));
                    add(getDate(2024, 3, 6));
                }},
                ReservationStatus.PENDING,
                2,
                new ArrayList<>() {{
                    add(ButtonType.ACCEPT);
                    add(ButtonType.DECLINE);
                }}
        ));
        ss2.add(new ReservationSummary(
                new ArrayList<>() {{
                    add(getDate(2024, 3, 5));
                    add(getDate(2024, 3, 6));
                }},
                ReservationStatus.PENDING,
                2,
                new ArrayList<>() {{
                    add(ButtonType.ACCEPT);
                    add(ButtonType.DECLINE);
                }}
        ));
    }

    private static Date getDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1); // Calendar months are 0-indexed
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, 0); // Clear out the hour, minute, second, and millisecond
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0); // Clear out the hour, minute, second, and millisecond
        return calendar.getTime();
    }

    @Test
    public void testGuest() throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(GUEST_EMAIL, GUEST_PASSWORD);

        HomePage homePage = new HomePage(driver);
        assertTrue(homePage.isPageOpened());

        assertEquals(homePage.getNumberOfNavigationBarTabs(), NUMBER_OF_NAVIGATION_BAR_TABS_GUEST);

        homePage.clickOnMyReservationsIcon();

        ReservationsPage reservationsPage = new ReservationsPage(driver);
        assertTrue(reservationsPage.isPageOpened());

        ArrayList<ReservationSummary> summaries = reservationsPage.getReservationSummaries();
        assertEquals(summaries.size(), reservationsPage.getNumberInHeading());
        assertEquals(ss.size(), summaries.size());

        for (int i = 0; i < ss.size(); i++) {
            assertEquals(ss.get(i).getDates().get(0), summaries.get(i).getDates().get(0));
            assertEquals(ss.get(i).getDates().get(1), summaries.get(i).getDates().get(1));

            assertEquals(ss.get(i).getStatus(), summaries.get(i).getStatus());
            assertEquals(ss.get(i).getGuestCount(), summaries.get(i).getGuestCount());

            for (int j = 0; j < ss.get(i).getButtons().size(); j++) {
                assertEquals(ss.get(i).getButtons().get(j), summaries.get(i).getButtons().get(j));
            }
        }

//        homePage.clickOnSignOutIcon();
    }

    @Test
    public void testHost() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(HOST_EMAIL, HOST_PASSWORD);

        HomePage homePage = new HomePage(driver);
        assertTrue(homePage.isPageOpened());

        assertEquals(homePage.getNumberOfNavigationBarTabs(), NUMBER_OF_NAVIGATION_BAR_TABS_HOST);

        homePage.clickOnMyReservationsIcon();

        ReservationsPage reservationsPage = new ReservationsPage(driver);
        assertTrue(reservationsPage.isPageOpened());

        ArrayList<ReservationSummary> summaries = reservationsPage.getReservationSummaries();
        assertEquals(summaries.size(), reservationsPage.getNumberInHeading());
        assertEquals(ss2.size(), summaries.size());

        for (int i = 0; i < ss2.size(); i++) {
            assertEquals(ss2.get(i).getDates().get(0), summaries.get(i).getDates().get(0));
            assertEquals(ss2.get(i).getDates().get(1), summaries.get(i).getDates().get(1));

            assertEquals(ss2.get(i).getStatus(), summaries.get(i).getStatus());
            assertEquals(ss2.get(i).getGuestCount(), summaries.get(i).getGuestCount());

            for (int j = 0; j < ss2.get(i).getButtons().size(); j++) {
                assertEquals(ss2.get(i).getButtons().get(j), summaries.get(i).getButtons().get(j));
            }
        }
    }

    @Test(dependsOnMethods = "testHost")
    public void testHost_accept_overlap() {
        ReservationsPage reservationsPage = new ReservationsPage(driver);

        reservationsPage.clickOnAcceptButton();
        ArrayList<ReservationSummary> summaries = reservationsPage.getReservationSummaries();
        assertEquals(summaries.size(), reservationsPage.getNumberInHeading());
        assertEquals(ss2.size(), summaries.size());
        assertSame(summaries.get(3).getStatus(), ReservationStatus.ACCEPTED);
        assertSame(summaries.get(4).getStatus(), ReservationStatus.DECLINED);
    }

    @Test(dependsOnMethods = "testHost")
    public void testHost_decline_overlap() {
        ReservationsPage reservationsPage = new ReservationsPage(driver);

        reservationsPage.clickOnDeclineButton();
        ArrayList<ReservationSummary> summaries = reservationsPage.getReservationSummaries();
        assertEquals(summaries.size(), reservationsPage.getNumberInHeading());
        assertEquals(ss2.size(), summaries.size());
        assertSame(summaries.get(3).getStatus(), ReservationStatus.DECLINED);
        assertSame(summaries.get(4).getStatus(), ReservationStatus.PENDING);
        assertTrue(summaries.get(3).getButtons().isEmpty());
        assertFalse(summaries.get(4).getButtons().isEmpty());
    }

    @Test(dependsOnMethods = "testGuest")
    public void testGuest_cancel() {
        ReservationsPage reservationsPage = new ReservationsPage(driver);

        reservationsPage.clickOnCancelButton();
        ArrayList<ReservationSummary> summaries = reservationsPage.getReservationSummaries();
        assertEquals(summaries.size(), reservationsPage.getNumberInHeading());
        assertEquals(ss.size(), summaries.size());
        assertSame(summaries.get(3).getStatus(), ReservationStatus.CANCELLED);
        assertTrue(summaries.get(3).getButtons().isEmpty());
    }

    @Test(dependsOnMethods = "testGuest")
    public void testGuest_delete() {
        ReservationsPage reservationsPage = new ReservationsPage(driver);

        reservationsPage.clickOnDeleteButton();
        ArrayList<ReservationSummary> summaries = reservationsPage.getReservationSummaries();
        assertEquals(summaries.size(), reservationsPage.getNumberInHeading());
        assertEquals(summaries.size(), ss.size()-1);

        for (int i = 0; i < ss.size()-1; i++) {
            assertEquals(ss.get(i).getDates().get(0), summaries.get(i).getDates().get(0));
            assertEquals(ss.get(i).getDates().get(1), summaries.get(i).getDates().get(1));

            assertEquals(ss.get(i).getStatus(), summaries.get(i).getStatus());
            assertEquals(ss.get(i).getGuestCount(), summaries.get(i).getGuestCount());

            for (int j = 0; j < ss.get(i).getButtons().size(); j++) {
                assertEquals(ss.get(i).getButtons().get(j), summaries.get(i).getButtons().get(j));
            }
        }
    }

}
