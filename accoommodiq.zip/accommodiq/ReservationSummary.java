package example.pages.accommodiq;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReservationSummary {
    ArrayList<Date> dates;
    ReservationStatus status;
    int guestCount;
    ArrayList<ButtonType> buttons;

    public ReservationSummary(ArrayList<Date> dates, ReservationStatus status, int guestCount, ArrayList<ButtonType> buttons) {
        this.dates = dates;
        this.status = status;
        this.guestCount = guestCount;
        this.buttons = buttons;
    }

    public ArrayList<Date> getDates() {
        return dates;
    }

    public void setDates(ArrayList<Date> dates) {
        this.dates = dates;
    }

    public ReservationStatus getStatus() {
        return status;
    }

    public void setStatus(ReservationStatus status) {
        this.status = status;
    }

    public int getGuestCount() {
        return guestCount;
    }

    public void setGuestCount(int guestCount) {
        this.guestCount = guestCount;
    }

    public ArrayList<ButtonType> getButtons() {
        return buttons;
    }

    public void setButtons(ArrayList<ButtonType> buttons) {
        this.buttons = buttons;
    }
}
