package example.pages.accommodiq;

public enum ReservationStatus {
    PENDING,
    ACCEPTED,
    CANCELLED,
    DECLINED,
}
