package example.pages.accommodiq;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReservationsPage {
    WebDriver driver;

    @FindBy(css = "app-reservation-card")
    List<WebElement> reservationCards;

    @FindBy(tagName = "h1")
    WebElement heading;

    public ReservationsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isPageOpened() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        return wait.until((WebDriver d) -> d.getCurrentUrl().contains("my-reservations"));
    }

    public ArrayList<ReservationSummary> getReservationSummaries() {
        ArrayList<ReservationSummary> reservationSummaries = new ArrayList<>();
        for (WebElement reservationCard : reservationCards) {
            List<WebElement> info = reservationCard.findElements(By.cssSelector(".icon-label > p"));
            List<String> infoText = info.stream().map(WebElement::getText).collect(java.util.stream.Collectors.toList());
            List<WebElement> buttons = reservationCard.findElements(By.cssSelector("button"));
            List<String> buttonText = buttons.stream().map(WebElement::getText).collect(java.util.stream.Collectors.toList());
            ArrayList<ButtonType> buttonTypes = buttonText.stream().map(this::getButtonType).collect(java.util.stream.Collectors.toCollection(ArrayList::new));
            reservationSummaries.add(new ReservationSummary(
                getDatesFromString(infoText.get(2)),
                getReservationStatus(infoText.get(3)),
                getGuestCount(infoText.get(1)),
                buttonTypes
            ));
        }
        return reservationSummaries;
    }

    private int getGuestCount(String guestCountText) {
        return Integer.parseInt(guestCountText.split(" ")[0]);
    }

    public int getNumberInHeading() {
        return Integer.parseInt(heading.getText().split(" ")[0]);
    }

    private ArrayList<Date> getDatesFromString(String str) {
        ArrayList<Date> dateList = new ArrayList<>();

        String[] dateStrings = str.split(" - ");

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");

        try {
            Date startDate = dateFormat.parse(dateStrings[0]);
            dateList.add(startDate);

            Date endDate = dateFormat.parse(dateStrings[1]);
            dateList.add(endDate);
        } catch (ParseException ignored) {
        }

        return dateList;
    }

    private ReservationStatus getReservationStatus(String statusText) {
        return ReservationStatus.valueOf(statusText.toUpperCase());
    }

    private ButtonType getButtonType(String buttonText) {
        return ButtonType.valueOf(buttonText.toUpperCase());
    }
}
